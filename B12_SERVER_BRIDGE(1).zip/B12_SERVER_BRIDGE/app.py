import os, sqlite3, secrets, hashlib, time
from functools import wraps
from flask import Flask, request, jsonify, render_template, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.getenv("DATABASE_PATH", os.path.join(BASE, "b12.db"))
app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "CHANGE-ME-" + secrets.token_hex(24))
ADMIN_USER = os.getenv("ADMIN_USER", "admin")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "ChangeThisNow123!")

def db():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    return c

def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT, api_key TEXT UNIQUE, created REAL);
        CREATE TABLE IF NOT EXISTS settings(user_id INTEGER PRIMARY KEY, strategy TEXT DEFAULT 'ema_rsi', timeframe TEXT DEFAULT '1m', demo INTEGER DEFAULT 1, auto_enabled INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS signals(id INTEGER PRIMARY KEY, user_id INTEGER, asset TEXT, direction TEXT, strategy TEXT, timeframe TEXT, created REAL);
        """)
        if not c.execute("SELECT 1 FROM users WHERE username='demo'").fetchone():
            key = secrets.token_urlsafe(24)
            uid = c.execute("INSERT INTO users(username,password,api_key,created) VALUES(?,?,?,?)",
                ("demo", generate_password_hash("Demo12345!"), key, time.time())).lastrowid
            c.execute("INSERT INTO settings(user_id) VALUES(?)", (uid,))

def current_user():
    if not session.get("uid"): return None
    with db() as c: return c.execute("SELECT * FROM users WHERE id=?", (session["uid"],)).fetchone()

def login_required(fn):
    @wraps(fn)
    def inner(*a, **kw):
        if not current_user(): return redirect(url_for("login"))
        return fn(*a, **kw)
    return inner

@app.get("/")
def home():
    if current_user(): return redirect(url_for("dashboard"))
    return render_template("login.html")

@app.route("/login", methods=["GET","POST"])
def login():
    error = ""
    if request.method == "POST":
        u = request.form.get("username","").strip()
        p = request.form.get("password","")
        with db() as c: row = c.execute("SELECT * FROM users WHERE username=?", (u,)).fetchone()
        if row and check_password_hash(row["password"], p):
            session["uid"] = row["id"]; return redirect(url_for("dashboard"))
        error = "اسم المستخدم أو كلمة المرور غير صحيحة"
    return render_template("login.html", error=error)

@app.get("/logout")
def logout():
    session.clear(); return redirect(url_for("login"))

@app.get("/dashboard")
@login_required
def dashboard():
    u = current_user()
    with db() as c:
        s = c.execute("SELECT * FROM settings WHERE user_id=?", (u["id"],)).fetchone()
        signals = c.execute("SELECT * FROM signals WHERE user_id=? ORDER BY id DESC LIMIT 20", (u["id"],)).fetchall()
    return render_template("dashboard.html", user=u, settings=s, signals=signals)

@app.post("/api/settings")
@login_required
def save_settings():
    data = request.get_json(force=True)
    strategy = str(data.get("strategy","ema_rsi"))
    timeframe = str(data.get("timeframe","1m"))
    allowed_s = {"ema_rsi","order_block_watch","candle_wick","rsi_reversal"}
    allowed_t = {"5s","15s","30s","1m","5m","15m"}
    if strategy not in allowed_s or timeframe not in allowed_t:
        return jsonify(ok=False,error="إعداد غير صالح"),400
    with db() as c:
        c.execute("UPDATE settings SET strategy=?,timeframe=?,demo=1,auto_enabled=0 WHERE user_id=?",
                  (strategy,timeframe,session["uid"]))
    return jsonify(ok=True, message="تم حفظ الإعدادات. التداول الحقيقي غير مفعّل.")

@app.get("/api/status")
@login_required
def status():
    with db() as c: s=c.execute("SELECT * FROM settings WHERE user_id=?", (session["uid"],)).fetchone()
    return jsonify(ok=True, server="online", mode="DEMO / SIGNALS ONLY", settings=dict(s))

@app.post("/api/signal")
@login_required
def signal():
    data=request.get_json(force=True)
    asset=str(data.get("asset","EURUSD"))[:24]
    direction=str(data.get("direction","WAIT")).upper()
    if direction not in {"CALL","PUT","WAIT"}: return jsonify(ok=False),400
    with db() as c:
        s=c.execute("SELECT * FROM settings WHERE user_id=?",(session["uid"],)).fetchone()
        c.execute("INSERT INTO signals(user_id,asset,direction,strategy,timeframe,created) VALUES(?,?,?,?,?,?)",
                  (session["uid"],asset,direction,s["strategy"],s["timeframe"],time.time()))
    return jsonify(ok=True, note="Signal stored. No order was sent to Quotex.")

@app.get("/admin")
def admin():
    if not session.get("admin"): return render_template("admin_login.html")
    with db() as c:
        users=c.execute("SELECT id,username,created FROM users ORDER BY id").fetchall()
    return render_template("admin.html", users=users)

@app.post("/admin/login")
def admin_login():
    if request.form.get("username")==ADMIN_USER and secrets.compare_digest(request.form.get("password",""),ADMIN_PASSWORD):
        session["admin"]=True; return redirect("/admin")
    return render_template("admin_login.html", error="بيانات المدير غير صحيحة")

@app.post("/admin/create-user")
def create_user():
    if not session.get("admin"): return redirect("/admin")
    username=request.form.get("username","").strip()
    password=request.form.get("password","")
    if len(username)<3 or len(password)<10: return redirect("/admin")
    key=secrets.token_urlsafe(24)
    try:
        with db() as c:
            uid=c.execute("INSERT INTO users(username,password,api_key,created) VALUES(?,?,?,?)",
              (username,generate_password_hash(password),key,time.time())).lastrowid
            c.execute("INSERT INTO settings(user_id) VALUES(?)",(uid,))
    except sqlite3.IntegrityError: pass
    return redirect("/admin")

@app.get("/health")
def health(): return jsonify(status="ok", service="B12 Server Bridge", trading="disabled")

init_db()
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT","8080")))
