# Quotex adapter status

No verified official Quotex trading API credentials/specification were provided. Therefore this project deliberately does not automate login, scrape private endpoints, store session cookies, or submit trades. The current app is a demo signal/settings server only.

To add an integration safely, obtain a documented and permitted API from the platform/provider, implement it behind an explicit adapter interface, add request signing, timeouts, idempotency, audit logs, risk limits, and a hard demo/live kill switch. Never commit secrets.
