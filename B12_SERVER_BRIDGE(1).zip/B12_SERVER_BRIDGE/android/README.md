# Android wrapper

The web app is mobile responsive. To produce an installable APK, use Android Studio to create a WebView shell pointing to your deployed HTTPS URL, or use the GitHub Actions workflow in this repository. The APK is a web wrapper and requires network access to the server. For production distribution, configure package ID, app signing key, and privacy policy.
